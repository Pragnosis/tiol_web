export const footerArr = [
    {
        title: "Tiol Info",
        list: [
            {
                label: "ABOUT",
                route: "https://www.google.com/"
            },
            {
                label: "CONTACT",
                route: "https://www.google.com/"
            },
            {
                label: "ACCOLADES",
                route: "https://www.google.com/"
            },
            {
                label: "MEMBERS",
                route: "https://www.google.com/"
            },
            {
                label: "GOVT RESPONSE",
                route: "https://www.google.com/"
            },
            {
                label: "MEDIA COVERAGE",
                route: "https://www.google.com/"
            },
            {
                label: "WORK WITH TIO",
                route: "https://www.google.com/"
            },
        ]
    },
    {
        title: "TIOL COLUMNS",
        list: [
            {
                label: "THE COB(WEB)",
                route: "https://www.google.com/"
            },
            {
                label: "JEST GST",
                route: "https://www.google.com/"
            },
            {
                label: "THE ICE CUBES",
                route: "https://www.google.com/"
            },
            {
                label: "TIOL EDIT",
                route: "https://www.google.com/"
            },
            {
                label: "DDT",
                route: "https://www.google.com/"
            },
            {
                label: "ST SE GST TAX",
                route: "https://www.google.com/"
            },
            {
                label: "GUEST COLUMNS",
                route: "https://www.google.com/"
            },
            {
                label: "AS I SEE IT",
                route: "https://www.google.com/"
            },
        ]
    },
    {
        title: "TIOL SEARCH",
        list: [
            {
                label: "CASE LAW ADVANCE SEARCH)",
                route: "https://www.google.com/"
            },
            {
                label: "CASE LAW QUICK SEARCH",
                route: "https://www.google.com/"
            },
            {
                label: "NOTIFICATION / CIRCULARSS",
                route: "https://www.google.com/"
            },
            {
                label: "COLUMNS SEARCH",
                route: "https://www.google.com/"
            },
            {
                label: "NEWS SEARCH",
                route: "https://www.google.com/"
            },
        ]
    },
    {
        title: "MEMBERS",
        list: [
            {
                label: "MESSAGE BOARD",
                route: "https://www.google.com/"
            },
            {
                label: "DAILY MAIL UPDATES",
                route: "https://www.google.com/"
            },
            {
                label: "SUBSCRIPTIONS",
                route: "https://www.google.com/"
            },
        ]
    }
]