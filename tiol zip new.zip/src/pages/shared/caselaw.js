import React from 'react'
import { Layout } from '../Layout'
import { Grid } from '@material-ui/core'

export const Caselaw = () => {
    return <Layout>
        <Grid container>
            <Grid item xs='8'>
                sadfgwadfsgaedgwedgrer ewr wer wergwe rwetrwe hteq
            </Grid>
            <Grid item xs='4'>
               
            </Grid>
        </Grid>
    </Layout>
}
